package javay.fsm;

public class Event {

}
