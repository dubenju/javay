/**
 * 
 */
/**
 * @author DBJ
 *
 */
package javay.fsm;