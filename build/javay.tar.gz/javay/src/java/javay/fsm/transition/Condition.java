package javay.fsm.transition;

public interface Condition {
	public boolean isGuard(String s);
}
