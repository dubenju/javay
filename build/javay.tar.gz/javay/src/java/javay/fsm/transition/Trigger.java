package javay.fsm.transition;

/**
 * Event
 * @author DBJ
 *
 */
public interface Trigger {

}
