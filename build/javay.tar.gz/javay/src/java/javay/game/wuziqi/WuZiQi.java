/**
 *
 */
package javay.game.wuziqi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

/**
 * @author DBJ
 *
 */
public class WuZiQi extends JFrame implements ActionListener {

	/**
	 *
	 */
	public WuZiQi() {
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	}

}
