/**
 *
 */
package javay.game;

/**
 * @author DBJ
 *
 */
public interface Board {

}
