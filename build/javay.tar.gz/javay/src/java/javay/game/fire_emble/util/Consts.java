package javay.game.fire_emble.util;

public class Consts {

    public static final int HCS = ImageManager.getInstance().getGround().getWidth(null);

    public static final int VCS = ImageManager.getInstance().getGround().getHeight(null);

    public static final int GROUND = 1;
}
