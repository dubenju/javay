package javay.classloader;

public class LocalClass {

    public void getName() {
        
      System.out.println("hahaha ");
    }
}