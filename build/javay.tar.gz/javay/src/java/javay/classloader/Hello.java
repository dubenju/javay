package javay.classloader;

public class Hello {  
	  
    public String sayHello(String name) {  
        return "Hello." + name;  
//        return "Hello.++" + name;
    }  
}  