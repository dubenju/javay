/**
 * 
 */
/**
 * @author dubenju
 *
 */
package javay.util;