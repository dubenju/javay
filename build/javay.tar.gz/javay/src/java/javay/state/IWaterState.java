package javay.state;

/**
 * 水的状态
 */
public interface IWaterState {
	/**
	 * 输出水的状态
	 */
	public void printState();
}
