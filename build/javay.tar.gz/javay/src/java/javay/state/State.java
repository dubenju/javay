package javay.state;

public interface State {
    public String sayHello();
    public String sayGoodbye();
}
