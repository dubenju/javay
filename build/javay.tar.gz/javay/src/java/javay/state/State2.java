package javay.state;

public interface State2 {
	/**
     * 状态对应的处理
     */
    public void handle(String sampleParameter);
}
