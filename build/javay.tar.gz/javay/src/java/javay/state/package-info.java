/**
 * 
 */
/**
 * @author DBJ
 *
 */
package javay.state;