package javay.math;

public interface BigNumCallBack {
    public BigNum op(BigNum num1, BigNum num2);
}
