package javay.math.expr;

public class ExprToken {

}
