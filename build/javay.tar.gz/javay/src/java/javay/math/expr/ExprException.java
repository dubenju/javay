package javay.math.expr;

public class ExprException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExprException(String msg) {
		super(msg);
	}
}
