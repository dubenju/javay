package javay.math.expr;

public enum TokenType {
	NONE____,
    NUMBER__,
    OPERATOR,
    VARIABLE
}
