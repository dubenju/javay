/**
 * 
 */
/**
 * @author dubenju
 *
 */
package javay.math;