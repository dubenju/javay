/**
 * 
 */
/**
 * @author dubenju
 *
 */
package javay.awt.event;