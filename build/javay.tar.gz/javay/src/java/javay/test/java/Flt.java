package javay.test.java;

public class Flt {

    public static void main(String[] args) {
        float pi = 3.14159265f;
        float d  = 30.0f;
        float a = d * pi;
        System.out.println(a);
    }

}
