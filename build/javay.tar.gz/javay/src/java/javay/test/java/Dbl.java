package javay.test.java;

public class Dbl {

    public static void main(String[] args) {
        double pi = 3.141592653589793;
        double d = 30.0;
        double a = d * pi;
        System.out.println(a);
    }

}
