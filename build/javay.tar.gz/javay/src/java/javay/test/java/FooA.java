package javay.test.java;

public class FooA {
	public static final Bean fb = new Bean();
	public static Bean sb = new Bean();
}
