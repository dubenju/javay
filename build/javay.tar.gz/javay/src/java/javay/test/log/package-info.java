/**
 * 
 */
/**
 * @author dubenju
 *
 */
package javay.test.log;