/**
 *
 */
package javay.test;

/**
 * @author DBJ
 *
 */
public class ClaA {
	private String a;
	/**
	 *
	 */
	public ClaA() {
	}
	/**
	 * @return a
	 */
	public String getA() {
		return a;
	}
	/**
	 * @param a セットする a
	 */
	public void setA(String a) {
		this.a = a;
	}
}
