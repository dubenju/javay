cobc -I ../cbl -g -conf=FXPN0001.conf -x -o FXPN0001.exe FXPN0001.cob
