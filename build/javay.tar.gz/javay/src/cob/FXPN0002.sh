cobc -I ../cbl -g -conf=FXPN0001.conf -x -o FXPN0002.exe FXPN0002.cob
