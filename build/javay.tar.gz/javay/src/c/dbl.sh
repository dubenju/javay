gcc -v dbl.c -o dbl.exe
