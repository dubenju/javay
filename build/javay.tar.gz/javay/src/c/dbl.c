#include <stdio.h>

int main() {
    printf("%15.15f\n", 0.05+0.01);
    printf("%15.15f\n", 1.0-0.42);
    printf("%15.15f\n", 4.015*100);
    printf("%15.15f\n", 123.3/100);
    printf("%15.15f\n", 2.4);
    return 0;
}
