gcc -v flt.c -o flt.exe
