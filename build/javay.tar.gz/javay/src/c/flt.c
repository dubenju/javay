#include <stdio.h>

int main() {
    float pi = 3.14159265;
    float d  = 30.0;
    float a = d * pi;
    printf("%6.6f\n", a);
    return 0;
}
