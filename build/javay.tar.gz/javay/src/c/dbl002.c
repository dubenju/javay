#include <stdio.h>

int main() {
    double pi = 3.1415926535897932;
    double d = 30.0;
    double a = d * pi;
    printf("%15.15f\n", a);
    return 0;
}
