#include <stdio.h>

int main() {
    double pi = 3.141592653589793;
    double d = 30.0;
    double a = d * pi;
    printf("%16.16f\n", a);
    return 0;
}
